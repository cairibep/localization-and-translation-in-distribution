# distribution-of-software

.
├── LICENSE
├── README.md
├── dev_aberto
│   ├── __init__.py
│   ├── __pycache__
│   │   ├── __init__.cpython-313.pyc
│   │   └── dev_aberto.cpython-313.pyc
│   └── dev_aberto.py
├── requirements.txt
├── scripts
│   └── hello.py
├── setup.py
└── test_import.py